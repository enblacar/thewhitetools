# thewhitetools

Collection of functions and classes developed by Enrique Blanco Carmona
in order to facilitate bioinformatic tasks.
